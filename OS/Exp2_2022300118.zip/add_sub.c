#include <stdio.h>

void comp_addition(int r1, int i1, int r2, int i2){
    printf("(%d + %di) + (%d + %di) = (%d) + (%d)i\n", r1,i1,r2,i2,r1+r2,i1+i2);
}

void comp_subtraction(int r1, int i1, int r2, int i2){
    printf("(%d + %di) - (%d + %di) = (%d) + (%d)i\n", r1,i1,r2,i2,r1-r2,i1-i2);
}