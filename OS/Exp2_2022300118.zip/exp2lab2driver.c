#include <stdio.h>
#include <stdlib.h>
#include "lib_mylib3.h"
typedef struct Complex{
    int real;
    int imaginary;
} Complex;

int main()
{
    Complex a,b;
    printf("Enter real and imaginary component of first complex number:\n");
    scanf("%d %d",&a.real,&a.imaginary);
    printf("Enter real and imaginary component of second complex number:\n");
    scanf("%d %d",&b.real,&b.imaginary);

    comp_addition(a.real, a.imaginary, b.real, b.imaginary);

    comp_subtraction(a.real,a.imaginary,b.real, b.imaginary);

    comp_multiplication(a.real,a.imaginary,b.real, b.imaginary);

    comp_division(a.real,a.imaginary,b.real, b.imaginary);

return 0;
}