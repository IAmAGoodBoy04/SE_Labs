#include<stdio.h>
#include "lib_mylib.h"


void main()
{
    int n;
    printf("\nEnter size of array: ");
    scanf("%d", &n);
    printf("\nEnter elements: ");
    int arr[n];
    for (int i = 0; i < n; i++){
        scanf("%d", &arr[i]);
    }
    mergesort(arr,0,n-1);
    printf("\n\nSorted Array: ");
    for (int i = 0; i < n; i++){
        printf("%d ", arr[i]);
    }
    printf("\n\nEnter radius and height for cylinder: ");
    int r, h;
    scanf("%d %d", &r, &h);
    printf("\n\nVolume of cylinder: %f", vol_cylinder(r, h));
}
