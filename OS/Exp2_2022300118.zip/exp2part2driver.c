#include <stdio.h>
#include "lib_mylib2.h"

int main () {
	printf("Enter values of a and b: ");
	int a,b;
    scanf("%d %d",&a,&b);

	double aa = addition(a, b);
    double ss = subtraction(a , b);
    double mm = multiplication(a , b);
    double dd = division(a , b);

    double s = sine((double)a);
    double c = cosine((double)a);
    double t = tangent((double)a);

    double le = ln((double)a);
    double l10 = log_10((double)a);


    double e = epowx((double)a);
    double xy = xpowy((double)a, (double)b);

    int f = factorial(a);
	
	printf("The sum, difference, product and ratio of %d and %d are:\n%.2lf %.2lf %.2lf %.2lf \n",a,b, aa, ss, mm ,dd);
	
	printf("The values of sin,cos and tan of %d are:\n%lf %lf %lf \n",a ,s, c, t);
	
	printf("The values of the natural log and log base 10 of %d are:\n%lf %lf \n",a, le , l10);
	
	printf("The values of e^%d and %d^%d are:\n%lf %lf \n",a,a,b, e , xy);
	
	printf("The value of %d! is: %d \n",a, f);
	
	return 0;
}
