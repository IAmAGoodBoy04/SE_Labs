#include <stdio.h>
#include <math.h>

double epowx(double x) {
	return exp(x);
}

double xpowy(double x, double y) {
	return pow(x, y);
}
