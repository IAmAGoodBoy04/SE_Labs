double addition(double a,double b);
double subtraction(double a,double b);
double multiplication(double a,double b);
double division(double a,double b);

double ln(double x);
double log_10(double x);

double sine(double theta);
double cosine(double theta);
double tangent(double theta);

double epowx(double x);
double xpowy(double x, double y);

int factorial (int n);