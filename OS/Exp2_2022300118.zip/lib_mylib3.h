void comp_addition(int r1, int i1, int r2, int i2);

void comp_subtraction(int r1, int i1, int r2, int i2);

void comp_multiplication(int r1, int i1, int r2, int i2);

void comp_division(int r1, int i1, int r2, int i2);