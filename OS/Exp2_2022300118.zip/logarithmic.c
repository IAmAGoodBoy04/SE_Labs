#include <stdio.h>
#include <math.h>

double ln(double x) {
	return log(x);
}

double log_10(double x) {
	return log10(x);
}
