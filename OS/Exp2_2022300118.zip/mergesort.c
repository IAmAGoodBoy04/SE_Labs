#include<stdio.h>
#define inf 0x7fffffff

void merge(int* arr,int start, int mid, int end){
    int L[mid-start+2],R[end-mid+1];
    L[mid-start+1]=R[end-mid]=inf;
    for(int i=start;i<=mid;i++){
        L[i-start]=arr[i];
    }
    for(int i=mid+1;i<=end;i++){
        R[i-mid-1]=arr[i];
    }
    int i=0,l=0,r=0;
    for(int i=start;i<=end;i++){
        if(L[l]<R[r]){
            arr[i]=L[l];
            l++;
        }
        else{
            arr[i]=R[r];
            r++;
        }
    }
}

void mergesort(int* arr, int start, int end){
    if(start==end){
        return;
    }
    int mid=(end+start)/2;
    mergesort(arr,start,mid);
    mergesort(arr,mid+1,end);
    merge(arr,start,mid,end);
}
