#include <stdio.h>
#include <math.h>
void comp_multiplication(int r1, int i1, int r2, int i2){
    int re,im;
    re = r1*r2-i1*i2;
    im = r1*i2+r2*i1;
    printf("(%d + %di) * (%d + %di) = (%d) + (%d)i\n", r1,i1,r2,i2,re,im);
}
void comp_division(int r1, int i1, int r2, int i2){
    float re,im;
    int den = i2*i2+r2*r2;
    re = (r1*r2+i1*i2)/(float)den;
    im = (i1*r2-r1*i2)/(float)den;
    printf("(%d + %di) / (%d + %di) = (%.2f) + (%.2f)i\n", r1,i1,r2,i2,re,im);
}