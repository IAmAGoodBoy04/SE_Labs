#include<stdio.h>
#include<math.h>

double sine(double theta){
    return sin(theta);
}
double cosine(double theta){
    return cos(theta);
}
double tangent(double theta){
    return tan(theta);
}
