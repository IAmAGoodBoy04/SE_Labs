#include<stdio.h>
#include<math.h>
#define PI acos(-1.0)

double vol_cylinder(double radius, double height){
    return PI*radius*radius*height;
}