#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    int i;
    for (i = 0; i < 2; i++) {
        fork();
		fork();
    }
    printf("PID : %d parent PID:%d\n", getpid(),getppid());
    sleep(1);
    return 0;
}