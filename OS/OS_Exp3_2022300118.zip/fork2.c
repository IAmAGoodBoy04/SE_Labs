#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

void fork2()
{
    // child process because return value zero
    if (fork() == 0){
        printf("Hello from Child!\n");
        sleep(0.5);
    }

    // parent process because return value non-zero.
    else
        printf("Hello from Parent!\n");
}

int main()
{
    fork2();
    return 0;
}