#include <stdio.h>
#include <unistd.h>

int main()
{
    int pid = fork();

    if (pid > 0)
        printf("In parent process,PID: %d\n",getpid());
    else if (pid == 0)
    {
        sleep(2);
        printf("In child process,PID:%d, PPID:%d\n",getpid(),getppid());
    }

    return 0;
}