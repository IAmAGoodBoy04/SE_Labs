#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void waitfunc(){
    int pid = fork();
    if (pid > 0){
        printf("Waiting for child to terminate...\n");
        wait(NULL);
        printf("Child has terminated.\n");
    }
    else if (pid == 0){
        sleep(0.5);
        printf("In child process.\n");
    }
}
int main(){
    waitfunc();
    return 0;
}