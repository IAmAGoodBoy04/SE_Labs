#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
    pid_t child_pid = fork();
    if (child_pid > 0)
        sleep(5); // Parent process sleeps for 5 seconds
    else
        exit(1); // Child process exits immediately
    return 0;
}